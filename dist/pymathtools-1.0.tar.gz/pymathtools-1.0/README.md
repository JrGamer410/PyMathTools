# PyMathTools
 A really simple Python library to do some math operations
